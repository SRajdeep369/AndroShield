#include "omp.h"
#include <iostream>


using namespace std;
int main()
{
    int i=0;
    #pragma omp parallel for
    for(i=0; i < 10; i++)
    {
        cout<<i<<endl;
    }
    

    return 0;
}