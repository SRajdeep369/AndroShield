import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB as gnb
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

data = pd.read_csv('/home/rajdeep/LP1/DA Practice/Medical Dibetes Data/pima-indians-diabetes.csv')

features = ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'BMI', 'Age', 'Insulin', 'DiabetesPedigreeFunction']
target = 'Class'
train, test = train_test_split(data, test_size=0.2)
clf = gnb().fit(train[features], train[target]) 
y_predicted = clf.predict(test[features])
print("Accuracy ",round(accuracy_score(test[target], y_predicted)*100,2)," %")
