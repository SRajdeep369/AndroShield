import csv
import pandas as pd
import numpy as np
from sklearn import linear_model
import matplotlib.pyplot as plt

df= pd.read_csv('airlines.csv')
FlightDate = df['FlightDate'].tolist()
passengers = df['Passengers'].tolist()

x = [28]

linear_mod = linear_model.LinearRegression() #defining the linear regression model
FlightDate = np.reshape(FlightDate,(len(FlightDate),1)) # converting to matrix of n X 1
passengers = np.reshape(passengers,(len(passengers),1))
linear_mod.fit(FlightDate,passengers) #fitting the data points in the model
plt.scatter(FlightDate,passengers,color='yellow') #plotting the initial datapoints 
plt.show()
plt.plot(FlightDate,linear_mod.predict(FlightDate),color='blue',linewidth=3) #plotting the line made by linear regression
plt.show()
x = np.asarray(x)
predicted_passengers =linear_mod.predict(x.reshape(-1,1))
print(predicted_passengers)

