import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
from utilities import visualize_classifier

df = pd.read_csv("2010-capitalbikeshare-tripdata.csv")

df.loc[df["Member type"] == 'Member', "Member type"] = 1
df.loc[df["Member type"] == 'Casual', "Member type"] = 2
df.loc[df["Member type"] == 'Unknown', "Member type"] = 3

train,test = train_test_split(df,test_size=0.3)
X = train[["Duration","Start station number","End station number"]]
y = train["Member type"]
X_test = test[["Duration","Start station number","End station number"]]
y_test = test["Member type"]
classifier = LogisticRegression()
classifier.fit(X,y)
y_predicted = classifier.predict(X_test)
score = round(accuracy_score(y_test,y_predicted)*100,2)
print("Accuracy",score)
